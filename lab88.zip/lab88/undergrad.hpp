/*========================================================================
 * Matthew Hawkins
 * Week 8 Check-In / Lab Demo
 * ======================================================================*/

/*=======================================================================
 * Here, I am combining my header and implementation files into one,
 * hence the .hpp extension. You should not do this in your programs,
 * but I've done this to reduce the number of files you need to download
 * should you want to look at the code.
 * ======================================================================*/

 /*======================REFERENCED MATERIAL=============================
 * Classes
 * Header Guards
 * Encapsulation (public, private, protected)
 * Constructors
 * Getters/Setters
 * Polymorphism/Inheritance
 * This pointer
 * Const Functions/Parameters
 * Pass by Reference
 * ======================================================================*/

#ifndef UNDERGRAD_H
#define UNDERGRAD_H

#include "person.hpp"


/*=======================================================================================
* This class inherits from the person class, as shown in the syntax below:
*======================================================================================*/

class Undergrad: public Person{

/*=======================================================================================
* One additional member variable that will be unique to this class and its children is
* being added.
*======================================================================================*/
    protected:
        float GPA;


    public:
        /*===Default Constructor===*/
        /*=======================================================================================
         * This constructor makes use of the parameterized constructor in the base Person class
         * by first setting our undergrad object's values inherited from person class to those 
         * passed into the person constructor. It will then set the undergrad object's GPA member
         * to its default value.
         *======================================================================================*/
        Undergrad() : Person("Generic Student", 18, 1234567980, false){
            this -> GPA = 4.0;
        }


        /*===Parameterized Constructor===*/
        /*=======================================================================================
         * Similar to the above constructor, but here, we're taking values in from our Undergrad
         * constructor and passing them to the Person constructor instead of using literals 
         * (hardcoded values) in our person constructor.
         *======================================================================================*/
        Undergrad(const string & new_name, const int & new_age, const double & new_id_num, const bool & new_is_employee, int const & new_GPA) 
            : Person(new_name, new_age, new_id_num, new_is_employee){
            this -> GPA = new_GPA;
        }


        /*===Getter(Accessor)===*/
        /*=======================================================================================
         * This function was written to return GPA, as this isn't included in the inherited
         * getters. Written as const to ensure GPA is not changed, just returned.
         *======================================================================================*/
        float get_GPA() const{
            return this -> GPA;
        }


        /*===Setter(Mutator)===*/
        /*=======================================================================================
         * Not included in inherited funtions, parameter is const and by reference for best
         * practice.
         *======================================================================================*/
        void set_GPA(const float & new_GPA){
            this -> GPA = new_GPA;
        }


        /*===Print Function===*/
        /*=======================================================================================
         * This is the re-definition of the pure virtual print function that was created in the
         * person class. We re-define it here so that our undergrad class does not become abstract
         * and so that the data stored inside can be easily displayed to the user.
         *======================================================================================*/
        void print_info(){
            char is_emp = 'N';
            if(is_employee){
                is_emp = 'Y';
            }
            cout << "Student's name: " << name << "\n";
            cout << "Student's age: " << age << "\n";
            cout << "Student's ID num: " << id_num << "\n";
            cout << "Is student employee: " << is_emp << "\n";
            cout << "Student's GPA: " << GPA << "\n" << endl;
        }
};



#endif