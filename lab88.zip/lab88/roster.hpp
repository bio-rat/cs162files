/*========================================================================
 * Matthew Hawkins
 * Week 8 Check-In / Lab Demo
 * ======================================================================*/

 /*======================REFERENCED MATERIAL=============================
 * Classes
 * Header Guards
 * Encapsulation (public, private, protected)
 * Constructors
 * Getters/Setters
 * Big Three
 * Polymorphism/Inheritance
 * This pointer
 * Const Functions/Parameters
 * Pass by Reference
 * Templates
 * Dynamic Array Manipulation (adding/removing data)
 * ======================================================================*/


#ifndef ROSTER_H
#define ROSTER_H

#include "person.hpp"
#include "undergrad.hpp"
#include "ta.hpp"
#include "instructor.hpp"

/*=======================================================================
 * This file MUST have both the header and implementation files combined, 
 * as the template declaration before my class definition must be kept 
 * with the implementation of the class's functions, otherwise it won't 
 * work properly!
 * ======================================================================*/

/*=======================================================================
 * This is how we create a template class, and then we'll use "T" 
 * wherever we want a member variable to be able to take different types
 * of data.
 * ======================================================================*/
template <class T>
class Roster{

    /*=======================================================================
    * Here, we have a pointer of type "T" which will allow us to create a 
    * dynamic array of whatever type we declare. Our num_people should keep
    * track of the number of items in this T array.
    * ======================================================================*/
    private:
        T * list_of_people;
        int num_people;

    public:
        /*===Default Constructor===*/
        /*=======================================================================================
         * We start our class off with a NULL pointer and number of people as 0. We'll use our
         * add and remove functions to edit this later.
         *======================================================================================*/
        Roster(){
            list_of_people = NULL;
            num_people = 0;
        }

        /*===Destructor===*/    /*===BIG 3 PART 1===*/
        /*=======================================================================================
         * This destructor will get rid of our dynamic memory one our class goes out of scope. 
         *
         * NOTE - If we have dynamic memory contained within each index (i.e if we've allocated
         * memory ourselves in an/each index), we would still need to free that memory before we
         * allow the destructor to be called!
         *======================================================================================*/
        ~Roster(){
            delete [] list_of_people;
        }


        /*===Copy Constructor===*/    /*===BIG 3 PART 2===*/
        /*=======================================================================================
         * The copy constructor is called when we want to:
         * CREATE a NEW object and SET IT EQUAL to one that exists AT THE SAME TIME/SAME LINE
         * We will allocate a new dynamic array of the appropriate size and copy the information
         * over from the existing item, and set other data members equal to those of the existing
         * object.
         *======================================================================================*/
        Roster(const Roster<T> & current){
            this -> num_people = current.num_people;
            this -> list_of_people = new T[num_people];
            for(int x = 0; x < num_people; x++){
                this->list_of_people = current.list_of_people[x];
            }
        }

        /*===Assignment Operator Overload===*/    /*===BIG 3 PART 3===*/
        /*=======================================================================================
         * The copy constructor is called when we want to:
         * Set an object that ALREADY EXISTS equal to another one that ALREADY EXISTS.
         * Similar to the copy constructor, but first, we need to check and make sure we aren't
         * trying to set our object equal to itself. If we aren't, we delete the old dynamic 
         * memory, then do what we did in the copy constructor, and allocate memory of a size 
         * that matches the object we're equaling, and copy those values over.
         *======================================================================================*/
        void operator = (const Roster<T> & current){
            if(this != &current){
                delete [] this -> list_of_people;
                this -> num_people = current.num_people;
                this -> list_of_people = new T[num_people];
                for(int x = 0; x < num_people; x++){
                    this->list_of_people = current.list_of_people[x];
                }
            }
        }

        /*===Getters(Accessors)===*/
        /*=======================================================================================
         * This function is written as const, because it is only returning a value, and
         * should not alter or change anything.
         *======================================================================================*/
        int get_num_people() const{
            return this -> num_people;
        }

        /*===Adding Function===*/
        /*=======================================================================================
         * This function will add a value to our array. It does this by creating a new temp array
         * of templates with a size one larger than our original array. We then copy the values
         * over, assign the value passed in to the end of the array, and then delete the array
         * our list_of_people variable was pointing to. Then, we "re-point" our array to the
         * one that is being pointed to by temp, so that when the function goes out of scope, 
         * and our temp variable is deleted, the list_of_people pointer still has that array's
         * address.
         *======================================================================================*/
        void add_person(const T & new_person){
            T * temp = new T [++num_people];
            for(int x = 0; x < this -> num_people - 1; x++){
                temp[x] = this -> list_of_people[x];
            }
            temp[num_people - 1] = new_person;
            delete [] this -> list_of_people;
            this -> list_of_people = temp;
        }

        /*===Removing Function===*/
        /*=======================================================================================
         * This function removes a value in the array. We create another temp array with size -1,
         * and then set up a for loop structure that allows us to skip over the desired index, 
         * and copy the rest of the values from our list_of_people array to the temp array. Then,
         * similarly to our add function, we delete the old array, and re-assign list_of_people.
         *======================================================================================*/
        void remove_person(int index){
            T * temp = new T [--num_people];
            for(int x = 0; x < index; x++){
                temp[x] = this -> list_of_people[x];
            }
            for(int y = index + 1; y < this -> num_people; y++){
                temp[y] = list_of_people[y];
            }
            delete [] list_of_people;
            this -> list_of_people = temp;
        }

        /*===Printing Function===*/
        /*=======================================================================================
         * This function simply calls the "print info" defined in each of our classes.
         *
         * NOTE - THIS IS NOT POLYMORPHISM!! While we wrote our function to work polymorphically,
         * the reason the correct print_into() function is called for each class is because we've
         * used a template class, and have created three different types of rosters, one of each
         * of our university members. To utilize polymorphism, we would have needed to use the
         * addresses of each of these, such as storing the addresses of our objects in an array
         * of base class person pointers.
         *======================================================================================*/
        void print_roster(){
            for(int x = 0; x < num_people; x++){
                list_of_people[x].print_info();
            }
        }
};


#endif