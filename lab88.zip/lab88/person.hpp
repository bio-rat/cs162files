/*========================================================================
 * Matthew Hawkins
 * Week 8 Check-In / Lab Demo
 * ======================================================================*/

/*============================DISCLAIMER=================================
 * Here, I am combining my header and implementation files into one,
 * hence the .hpp extension. You should not do this in your programs,
 * but I've done this to reduce the number of files you need to download
 * should you want to look at the code.
 * ======================================================================*/

 /*======================REFERENCED MATERIAL=============================
 * Classes
 * Header Guards
 * Encapsulation (public, private, protected)
 * Constructors
 * Getters/Setters
 * Inheritance/Polymorphism (Pure virtual function/abstract class)
 * This pointer
 * Const Functions/Parameters
 * Pass by Reference
 * ======================================================================*/

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <stdlib.h>

using namespace std; //DO NOT USE THIS FOR LAB 8

class Person{

    protected:
        string name;
        int age;
        double id_num;
        bool is_employee;
        

    public:
        /*===Default Constructor===*/
        /*=======================================================================================
         * NOTE - The implicit "this" pointer is not used in this constructor to show that 
         * using it and not using it will often produce the same effects, and to highlight
         * the differences in syntax. 
         *======================================================================================*/
        Person(){
            name = "Generic Human";
            age = 18;
            id_num = 123456789;
            is_employee = false;
        }

        /*===Parameterized Constructor===*/
        /*=======================================================================================
         * Uses const and & in argument list, as these values should not be changed (const),
         * and passing by reference is more memory efficient.
         * 
         * NOTE - From here on out, we'll be using the implicit "this" pointer to make sure you
         * are familiar with seeing it. It does not change functionality in these functions, but
         * simply aids readability. Notice its use here, its absence in the default constructor,
         * and how both functions work!
         *======================================================================================*/
        Person(const string & new_name, const int & new_age, const int & new_id_num, const bool & new_is_employee){
            this -> name = new_name;
            this -> age = new_age;
            this -> id_num = new_id_num;
            this -> is_employee = new_is_employee;
        }


        /*===Getters(Accessors)===*/
        /*=======================================================================================
         * These functions are written as const, because they are only returning a value, and
         * should not alter or change anything.
         *======================================================================================*/
        string get_name() const{
            return this -> name;
        }

        int get_age() const{
            return this -> age;
        }

        double get_id_num() const{
            return this -> id_num;
        }

        bool get_is_employee() const{
            return this -> is_employee;
        }


        /*===Setters(Mutators)===*/
        /*=======================================================================================
         * Uses const and & in argument list, as these values should not be changed (const),
         * and passing by reference is more memory efficient.
         *======================================================================================*/

        void set_name(const string & new_name){
            this -> name = new_name;
        }

        void set_age(const int & new_age){
            this -> age = new_age;
        }

        void set_id_num(const double & new_id_num){
            this -> id_num = new_id_num;
        }

        void set_is_employee(const bool & new_is_employee){
            this -> is_employee = new_is_employee;
        }


        /*===Pure Virtual Print Function===*/
        /*=======================================================================================
         * This function is a PURE VIRTUAL function, which makes this class abstract, meaning it
         * cannot be instantiated (cannot create a variable of this class), and forces other
         * classes that inherit from it to re-define this function, or they also become abstract.
         * 
         * Pure virtual functions make use of the virtual keyword, do not have any definition 
         * in their .cpp file, and are set to " = 0 " at the end of the function declaration.
         * 
         * TAKE NOTE that this demo DOES NOT make overt use of polymorphism, but shows the syntax as
         * a reminder.
         *======================================================================================*/
        virtual void print_info() = 0;
};



#endif