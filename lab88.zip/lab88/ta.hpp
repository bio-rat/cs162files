/*========================================================================
 * Matthew Hawkins
 * Week 8 Check-In / Lab Demo
 * ======================================================================*/

/*=======================================================================
 * Here, I am combining my header and implementation files into one,
 * hence the .hpp extension. You should not do this in your programs,
 * but I've done this to reduce the number of files you need to download
 * should you want to look at the code.
 * ======================================================================*/

 /*======================REFERENCED MATERIAL=============================
 * Classes
 * Header Guards
 * Encapsulation (public, private, protected)
 * Constructors
 * Getters/Setters
 * Polymorphism/Inheritance
 * This pointer
 * Const Functions/Parameters
 * Pass by Reference
 * ======================================================================*/

#ifndef TA_H
#define TA_H

#include "person.hpp"
#include "undergrad.hpp"

/*=======================================================================================
* This class inherits from the Undergrad class, as shown in the syntax below:
*======================================================================================*/

class TA: public Undergrad{

/*=======================================================================================
* Two additional member variables that will be unique to this class are being added. 
* These are in addition to the ones from our Undergrad and our Person classes.
*======================================================================================*/
    private:
        int num_labs;
        int num_hours;


    public:
        /*===Default Constructor===*/
        /*=======================================================================================
         * This constructor makes use of the parameterized constructor in the base Undergrad 
         * class by first setting our TA object's values inherited from undergrad class to  
         * those passed into the TA constructor. It will then set the TA object's other two 
         * members to their respective default value.
         *======================================================================================*/
        TA() : Undergrad("Generic Student", 18, 1234567980, true, 4.0){
            this -> num_labs = 0;
            this -> num_hours = 0;
        }

        /*===Parameterized Constructor===*/
        /*=======================================================================================
         * Similar to the above constructor, but here, we're taking values in from our TA
         * constructor and passing them to the Undergrad constructor instead of using literals 
         * (hardcoded values) in our Undergrad constructor.
         *======================================================================================*/
        TA(const string & new_name, const int & new_age, const double & new_id_num, const bool & new_is_employee, 
          const int & new_GPA, const int & new_num_labs, const int new_num_hours) 
            : Undergrad(new_name, new_age, new_id_num, new_is_employee, new_GPA){
            this -> num_labs = new_num_labs;
            this -> num_hours = new_num_hours;
        }

        /*===Getter(Accessor)===*/
        /*=======================================================================================
         * These functions were written to return num_labs and num_hours, as they aren't inherited
         * getters from Undergrad. Written as const to ensure values are not changed, just 
         * returned.
         *======================================================================================*/
        int get_num_labs() const{
            return this -> num_labs;
        }

        int get_num_hours() const{
            return this -> num_hours;
        }

        /*===Setter(Mutator)===*/
        /*=======================================================================================
         * Not included in inherited funtions, similar to our getters above. Parameter is const 
         * and by reference for best practice.
         *======================================================================================*/
        void set_num_labs(const int & new_num_labs){
            this -> num_labs = new_num_labs;
        }

        void set_num_hours(const int & new_num_hours){
            this -> num_hours = new_num_hours;
        }

        /*===Print Function===*/
        /*=======================================================================================
         * This is the re-definition of the pure virtual print function that was created in the
         * person class. We re-define it here so that our TA class does not become abstract
         * and so that the data stored inside can be easily displayed to the user.
         *======================================================================================*/
        void print_info(){
            char is_emp = 'N';
            if(is_employee){
                is_emp = 'Y';
            }
            cout << "Student's name: " << name << "\n";
            cout << "Student's age: " << age << "\n";
            cout << "Student's ID num: " << id_num << "\n";
            cout << "Is student employee: " << is_emp << "\n";
            cout << "Student's GPA: " << GPA << "\n";
            cout << "TA's number of labs: " << num_labs << "\n";
            cout << "TA's number of hours: " << num_hours << "\n" << endl;
        }
};



#endif