/*========================================================================
 * Matthew Hawkins
 * Week 8 Check-In / Lab Demo
 * ======================================================================*/

#include "instructor.hpp"
#include "ta.hpp"
#include "undergrad.hpp"
#include "roster.hpp"


int main (){


    
    
    /*=======================================================================================
    * This is how we create a template class with a desired data type. This could also be 
    * done with ints, chars, etc. I've chosen to fill them with classes, because classes 
    * are more fun :)
    *======================================================================================*/
    Roster<Undergrad> undergrads;
    Roster<TA> tas;
    Roster<Instructor> instructors;

    string name;
    int age;
    
    cout << "Who wants to get added to my demo?: ";
    cin >> name;
    cout << "Now you have to tell us how old you are. Or lie, idc: ";
    cin >> age;

    Undergrad u1;
    Undergrad u2 (name, age, 80087355, false, 4.0);
    TA t1;
    TA t2 ("Sergiy", 20, 1337, true, 4.0, 3, 20);
    Instructor i1;
    Instructor i2 ("Brandi Meme Lord", 30, 999999999, true, 5);


    undergrads.add_person(u1);
    undergrads.add_person(u2);

    tas.add_person(t1);
    tas.add_person(t2);

    instructors.add_person(i1);
    instructors.add_person(i2);

    cout << "================STUDENTS================"<< endl;
    undergrads.print_roster();
    cout << "===================TAs==================="<< endl;
    tas.print_roster();
    cout << "================INSTRUCTORS================"<< endl;
    instructors.print_roster();

    undergrads.remove_person(0);
    tas.remove_person(0);
    instructors.remove_person(0);

    cout << "\n\n\n================REMOVING MEMBERS================\n\n\n"<< endl;

    cout << "================STUDENTS================"<< endl;
    undergrads.print_roster();
    cout << "===================TAs==================="<< endl;
    tas.print_roster();
    cout << "================INSTRUCTORS================"<< endl;
    instructors.print_roster();
    



    return 0;
}