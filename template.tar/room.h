/*
	Room Class
*/
#ifndef ROOM_H
#define ROOM_H

#include <iostream>

using namespace std;

// Note that in your homework assignment, Room will actually use inheritance
class Room {
public:
	Room();
	Room(string name);
	string get_name();

private:
	string name;
	string volume;
};
#endif
